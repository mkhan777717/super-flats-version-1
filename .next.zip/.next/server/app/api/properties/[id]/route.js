(()=>{var e={};e.id=777,e.ids=[777],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},42996:(e,t,r)=>{"use strict";r.d(t,{i9:()=>u,yh:()=>d});var i=r(46101);let a={host:process.env.MYSQL_HOST||"localhost",port:Number.parseInt(process.env.MYSQL_PORT||"3306"),user:process.env.MYSQL_USER||"root",password:process.env.MYSQL_PASSWORD||"kamlesh12",database:process.env.MYSQL_DATABASE||"superflats_temp",waitForConnections:!0,connectionLimit:10,queueLimit:0},s=null;async function p(e,t=[]){try{let r=(s||(s=i.createPool(a)),s),[p]=await r.execute(e,t);return p}catch(e){throw console.error("Database query error:",e),e}}async function o(e,t=[]){return(await p(e,t))[0]||null}async function n(e,t=[]){return await p(e,t)}let u={async getAllProperties(){let e=`
      SELECT 
        p.*,
        GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.display_order) as images,
        GROUP_CONCAT(DISTINCT pa.amenity) as amenities
      FROM properties p
      LEFT JOIN property_images pi ON p.id = pi.property_id
      LEFT JOIN property_amenities pa ON p.id = pa.property_id
      GROUP BY p.id
      ORDER BY p.created_at DESC
    `;return(await n(e)).map(e=>({...e,images:e.images?e.images.split(","):[],amenities:e.amenities?e.amenities.split(","):[]}))},async getPropertyById(e){let t=`
      SELECT 
        p.*,
        GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.display_order) as images,
        GROUP_CONCAT(DISTINCT pa.amenity) as amenities
      FROM properties p
      LEFT JOIN property_images pi ON p.id = pi.property_id
      LEFT JOIN property_amenities pa ON p.id = pa.property_id
      WHERE p.id = ?
      GROUP BY p.id
    `,r=await o(t,[e]);return r?{...r,images:r.images?r.images.split(","):[],amenities:r.amenities?r.amenities.split(","):[]}:null},async createProperty(e){let{title:t,description:r,property_type:i,bhk_type:a,rent:s,deposit:o,location:n,area:u,furnished_status:d,parking:c,parking_type:l,floor_number:y,total_floors:m,age_of_property:_,facing:E,balcony:g,bathroom:O,available_from:h,contact_name:R,contact_phone:f,contact_email:T,images:N=[],amenities:S=[]}=e,I=`
      INSERT INTO properties (
        title, description, property_type, bhk_type, rent, deposit, location,
        area, furnished_status, parking, parking_type, floor_number, total_floors,
        age_of_property, facing, balcony, bathroom, available_from,
        contact_name, contact_phone, contact_email
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,x=(await p(I,[t,r,i,a,s,o,n,u,d,c,l,y,m,_,E,g,O,h,R,f,T])).insertId;if(N.length>0){let e=N.map((e,t)=>[x,e,t]);await p("INSERT INTO property_images (property_id, image_url, display_order) VALUES ?",[e])}if(S.length>0){let e=S.map(e=>[x,e]);await p("INSERT INTO property_amenities (property_id, amenity) VALUES ?",[e])}return x},async updateProperty(e,t){let{title:r,description:i,property_type:a,bhk_type:s,rent:o,deposit:n,location:u,area:d,furnished_status:c,parking:l,parking_type:y,floor_number:m,total_floors:_,age_of_property:E,facing:g,balcony:O,bathroom:h,available_from:R,contact_name:f,contact_phone:T,contact_email:N,images:S=[],amenities:I=[]}=t,x=`
      UPDATE properties SET
        title = ?, description = ?, property_type = ?, bhk_type = ?, rent = ?, 
        deposit = ?, location = ?, area = ?, furnished_status = ?, parking = ?,
        parking_type = ?, floor_number = ?, total_floors = ?, age_of_property = ?,
        facing = ?, balcony = ?, bathroom = ?, available_from = ?,
        contact_name = ?, contact_phone = ?, contact_email = ?, updated_at = NOW()
      WHERE id = ?
    `;if(await p(x,[r,i,a,s,o,n,u,d,c,l,y,m,_,E,g,O,h,R,f,T,N,e]),await p("DELETE FROM property_images WHERE property_id = ?",[e]),await p("DELETE FROM property_amenities WHERE property_id = ?",[e]),S.length>0){let t=S.map((t,r)=>[e,t,r]);await p("INSERT INTO property_images (property_id, image_url, display_order) VALUES ?",[t])}if(I.length>0){let t=I.map(t=>[e,t]);await p("INSERT INTO property_amenities (property_id, amenity) VALUES ?",[t])}return!0},deleteProperty:async e=>(await p("DELETE FROM properties WHERE id = ?",[e]),!0),async searchProperties(e){let t=`
      SELECT 
        p.*,
        GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.display_order) as images,
        GROUP_CONCAT(DISTINCT pa.amenity) as amenities
      FROM properties p
      LEFT JOIN property_images pi ON p.id = pi.property_id
      LEFT JOIN property_amenities pa ON p.id = pa.property_id
      WHERE p.title LIKE ? OR p.location LIKE ? OR p.description LIKE ?
      GROUP BY p.id
      ORDER BY p.created_at DESC
    `,r=`%${e}%`;return(await n(t,[r,r,r])).map(e=>({...e,images:e.images?e.images.split(","):[],amenities:e.amenities?e.amenities.split(","):[]}))}},d={validateAdmin:async(e,t)=>await o("SELECT * FROM admin_users WHERE email = ? AND password = ?",[e,t])}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},71667:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>E,routeModule:()=>l,serverHooks:()=>_,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>m});var i={};r.r(i),r.d(i,{DELETE:()=>c,GET:()=>u,PUT:()=>d});var a=r(96559),s=r(48088),p=r(37719),o=r(32190),n=r(42996);async function u(e,{params:t}){try{let e=await n.i9.getPropertyById(Number.parseInt(t.id));if(!e)return o.NextResponse.json({error:"Property not found"},{status:404});let r={id:e.id.toString(),name:e.title,location:e.location,bhk:e.bhk_type,rent:e.rent,deposit:e.deposit,availability:"available"===e.availability_status?"Available":"occupied"===e.availability_status?"Rented":"Maintenance",images:e.images||[],createdAt:e.created_at?new Date(e.created_at).toISOString().split("T")[0]:"",description:e.description,amenities:e.amenities||[],area:e.area,furnished:"fully_furnished"===e.furnished_status?"Fully Furnished":"semi_furnished"===e.furnished_status?"Semi Furnished":"Unfurnished",parking:e.parking,contact:e.contact_phone};return o.NextResponse.json(r)}catch(e){return console.error("Error fetching property:",e),o.NextResponse.json({error:"Failed to fetch property"},{status:500})}}async function d(e,{params:t}){try{let r=await e.json(),i={title:r.name,description:r.description,property_type:"apartment",bhk_type:r.bhk,rent:r.rent,deposit:r.deposit,location:r.location,area:r.area,furnished_status:"Fully Furnished"===r.furnished?"fully_furnished":"Semi Furnished"===r.furnished?"semi_furnished":"unfurnished",parking:r.parking||!1,parking_type:r.parking?"covered":"none",contact_phone:r.contact,images:r.images||[],amenities:r.amenities||[]};return await n.i9.updateProperty(Number.parseInt(t.id),i),o.NextResponse.json({message:"Property updated successfully"})}catch(e){return console.error("Error updating property:",e),o.NextResponse.json({error:"Failed to update property"},{status:500})}}async function c(e,{params:t}){try{return await n.i9.deleteProperty(Number.parseInt(t.id)),o.NextResponse.json({message:"Property deleted successfully"})}catch(e){return console.error("Error deleting property:",e),o.NextResponse.json({error:"Failed to delete property"},{status:500})}}let l=new a.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/properties/[id]/route",pathname:"/api/properties/[id]",filename:"route",bundlePath:"app/api/properties/[id]/route"},resolvedPagePath:"C:\\Users\\Saksham\\Downloads\\superflatss\\project\\app\\api\\properties\\[id]\\route.ts",nextConfigOutput:"",userland:i}),{workAsyncStorage:y,workUnitAsyncStorage:m,serverHooks:_}=l;function E(){return(0,p.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:m})}},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[447,580,101],()=>r(71667));module.exports=i})();