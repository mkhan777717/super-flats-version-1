(()=>{var e={};e.id=769,e.ids=[769],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14083:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>y,routeModule:()=>l,serverHooks:()=>_,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>m});var i={};r.r(i),r.d(i,{GET:()=>u,POST:()=>c});var a=r(96559),s=r(48088),p=r(37719),o=r(32190),n=r(42996);async function u(e){try{let t;let{searchParams:r}=new URL(e.url),i=r.get("search"),a=(i?await n.i9.searchProperties(i):await n.i9.getAllProperties()).map(e=>({id:e.id.toString(),name:e.title,location:e.location,bhk:e.bhk_type,rent:e.rent,deposit:e.deposit,availability:"available"===e.availability_status?"Available":"occupied"===e.availability_status?"Rented":"Maintenance",images:e.images||[],createdAt:e.created_at?new Date(e.created_at).toISOString().split("T")[0]:"",description:e.description,amenities:e.amenities||[],area:e.area,furnished:"fully_furnished"===e.furnished_status?"Fully Furnished":"semi_furnished"===e.furnished_status?"Semi Furnished":"Unfurnished",parking:e.parking,contact:e.contact_phone}));return o.NextResponse.json(a)}catch(e){return console.error("Error fetching properties:",e),o.NextResponse.json({error:"Failed to fetch properties"},{status:500})}}async function c(e){try{let t=await e.json(),r={title:t.name,description:t.description,property_type:"apartment",bhk_type:t.bhk,rent:t.rent,deposit:t.deposit,location:t.location,area:t.area,furnished_status:"Fully Furnished"===t.furnished?"fully_furnished":"Semi Furnished"===t.furnished?"semi_furnished":"unfurnished",parking:t.parking||!1,parking_type:t.parking?"covered":"none",availability_status:"available",contact_phone:t.contact,images:t.images||[],amenities:t.amenities||[]},i=await n.i9.createProperty(r);return o.NextResponse.json({id:i,message:"Property created successfully"})}catch(e){return console.error("Error creating property:",e),o.NextResponse.json({error:"Failed to create property"},{status:500})}}let l=new a.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/properties/route",pathname:"/api/properties",filename:"route",bundlePath:"app/api/properties/route"},resolvedPagePath:"C:\\Users\\Saksham\\Downloads\\superflatss\\project\\app\\api\\properties\\route.ts",nextConfigOutput:"",userland:i}),{workAsyncStorage:d,workUnitAsyncStorage:m,serverHooks:_}=l;function y(){return(0,p.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:m})}},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},42996:(e,t,r)=>{"use strict";r.d(t,{i9:()=>u,yh:()=>c});var i=r(46101);let a={host:process.env.MYSQL_HOST||"localhost",port:Number.parseInt(process.env.MYSQL_PORT||"3306"),user:process.env.MYSQL_USER||"root",password:process.env.MYSQL_PASSWORD||"kamlesh12",database:process.env.MYSQL_DATABASE||"superflats_temp",waitForConnections:!0,connectionLimit:10,queueLimit:0},s=null;async function p(e,t=[]){try{let r=(s||(s=i.createPool(a)),s),[p]=await r.execute(e,t);return p}catch(e){throw console.error("Database query error:",e),e}}async function o(e,t=[]){return(await p(e,t))[0]||null}async function n(e,t=[]){return await p(e,t)}let u={async getAllProperties(){let e=`
      SELECT 
        p.*,
        GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.display_order) as images,
        GROUP_CONCAT(DISTINCT pa.amenity) as amenities
      FROM properties p
      LEFT JOIN property_images pi ON p.id = pi.property_id
      LEFT JOIN property_amenities pa ON p.id = pa.property_id
      GROUP BY p.id
      ORDER BY p.created_at DESC
    `;return(await n(e)).map(e=>({...e,images:e.images?e.images.split(","):[],amenities:e.amenities?e.amenities.split(","):[]}))},async getPropertyById(e){let t=`
      SELECT 
        p.*,
        GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.display_order) as images,
        GROUP_CONCAT(DISTINCT pa.amenity) as amenities
      FROM properties p
      LEFT JOIN property_images pi ON p.id = pi.property_id
      LEFT JOIN property_amenities pa ON p.id = pa.property_id
      WHERE p.id = ?
      GROUP BY p.id
    `,r=await o(t,[e]);return r?{...r,images:r.images?r.images.split(","):[],amenities:r.amenities?r.amenities.split(","):[]}:null},async createProperty(e){let{title:t,description:r,property_type:i,bhk_type:a,rent:s,deposit:o,location:n,area:u,furnished_status:c,parking:l,parking_type:d,floor_number:m,total_floors:_,age_of_property:y,facing:E,balcony:g,bathroom:O,available_from:h,contact_name:R,contact_phone:T,contact_email:f,images:N=[],amenities:S=[]}=e,x=`
      INSERT INTO properties (
        title, description, property_type, bhk_type, rent, deposit, location,
        area, furnished_status, parking, parking_type, floor_number, total_floors,
        age_of_property, facing, balcony, bathroom, available_from,
        contact_name, contact_phone, contact_email
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,I=(await p(x,[t,r,i,a,s,o,n,u,c,l,d,m,_,y,E,g,O,h,R,T,f])).insertId;if(N.length>0){let e=N.map((e,t)=>[I,e,t]);await p("INSERT INTO property_images (property_id, image_url, display_order) VALUES ?",[e])}if(S.length>0){let e=S.map(e=>[I,e]);await p("INSERT INTO property_amenities (property_id, amenity) VALUES ?",[e])}return I},async updateProperty(e,t){let{title:r,description:i,property_type:a,bhk_type:s,rent:o,deposit:n,location:u,area:c,furnished_status:l,parking:d,parking_type:m,floor_number:_,total_floors:y,age_of_property:E,facing:g,balcony:O,bathroom:h,available_from:R,contact_name:T,contact_phone:f,contact_email:N,images:S=[],amenities:x=[]}=t,I=`
      UPDATE properties SET
        title = ?, description = ?, property_type = ?, bhk_type = ?, rent = ?, 
        deposit = ?, location = ?, area = ?, furnished_status = ?, parking = ?,
        parking_type = ?, floor_number = ?, total_floors = ?, age_of_property = ?,
        facing = ?, balcony = ?, bathroom = ?, available_from = ?,
        contact_name = ?, contact_phone = ?, contact_email = ?, updated_at = NOW()
      WHERE id = ?
    `;if(await p(I,[r,i,a,s,o,n,u,c,l,d,m,_,y,E,g,O,h,R,T,f,N,e]),await p("DELETE FROM property_images WHERE property_id = ?",[e]),await p("DELETE FROM property_amenities WHERE property_id = ?",[e]),S.length>0){let t=S.map((t,r)=>[e,t,r]);await p("INSERT INTO property_images (property_id, image_url, display_order) VALUES ?",[t])}if(x.length>0){let t=x.map(t=>[e,t]);await p("INSERT INTO property_amenities (property_id, amenity) VALUES ?",[t])}return!0},deleteProperty:async e=>(await p("DELETE FROM properties WHERE id = ?",[e]),!0),async searchProperties(e){let t=`
      SELECT 
        p.*,
        GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.display_order) as images,
        GROUP_CONCAT(DISTINCT pa.amenity) as amenities
      FROM properties p
      LEFT JOIN property_images pi ON p.id = pi.property_id
      LEFT JOIN property_amenities pa ON p.id = pa.property_id
      WHERE p.title LIKE ? OR p.location LIKE ? OR p.description LIKE ?
      GROUP BY p.id
      ORDER BY p.created_at DESC
    `,r=`%${e}%`;return(await n(t,[r,r,r])).map(e=>({...e,images:e.images?e.images.split(","):[],amenities:e.amenities?e.amenities.split(","):[]}))}},c={validateAdmin:async(e,t)=>await o("SELECT * FROM admin_users WHERE email = ? AND password = ?",[e,t])}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[447,580,101],()=>r(14083));module.exports=i})();